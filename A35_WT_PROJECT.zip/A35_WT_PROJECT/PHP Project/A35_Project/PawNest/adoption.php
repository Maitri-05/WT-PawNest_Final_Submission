<?php
session_start();
require_once __DIR__ . "/php/db.php";

$selectedPetId = (int)($_GET["pet_id"] ?? 0);
$selectedPet = null;

try {
    if ($selectedPetId > 0) {
        $stmt = $conn->prepare("SELECT * FROM pets WHERE id = :id");
        $stmt->execute([":id" => $selectedPetId]);
        $selectedPet = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Get list of all available pets for dropdown if not preselected
    $allPetsStmt = $conn->query("SELECT id, name, type, breed FROM pets WHERE status = 'Available' ORDER BY name ASC");
    $availablePets = $allPetsStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

$userName = $_SESSION["user_name"] ?? "";
$userEmail = $_SESSION["user_email"] ?? "";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Adopt <?php echo $selectedPet ? htmlspecialchars($selectedPet["name"]) : "a Pet"; ?> - PawNest</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <!-- Navigation Bar -->
    <header>

        <div class="logo">
            🐾 PawNest
        </div>

        <nav>
            <a href="index.php">Home</a>
            <a href="pets.php">Pets</a>
            <a href="how-it-works.html">How It Works</a>
            <a href="about-us.html">About Us</a>
            <?php if (isset($_SESSION["user_name"])) { ?>
                <a href="my-applications.php">My Applications</a>
                <span style="color:#e67e22; font-weight:bold; margin-left:15px;">Hi, <?php echo htmlspecialchars($_SESSION["user_name"]); ?>!</span>
                <a href="php/logout.php" style="color:#c0392b;">Logout</a>
            <?php } else { ?>
                <a href="login.php">Login</a>
                <a href="register.php" class="btn" style="padding:7px 15px; color:#fff;">Register</a>
            <?php } ?>
        </nav>

    </header>


    <!-- Adoption Form -->
    <section class="form-section">

        <div class="form-container">

            <h1>
                Adopt <?php echo $selectedPet ? htmlspecialchars($selectedPet["name"]) . " 🐾" : "a Pet 🐾"; ?>
            </h1>

            <p class="form-intro">
                Fill in the form below to submit your adoption application into the PawNest database.
            </p>

            <form action="php/submit-application.php" method="POST" onsubmit="return validateAdoption()">

                <!-- Select Pet -->
                <?php if ($selectedPet) { ?>
                    <input type="hidden" name="pet_id" value="<?php echo $selectedPet["id"]; ?>">
                    <div style="background:#fff0df; padding:12px 18px; border-radius:8px; margin-bottom:20px; font-weight:bold; color:#4a2c20;">
                        Applying for: 🐾 <?php echo htmlspecialchars($selectedPet["name"]); ?> (<?php echo htmlspecialchars($selectedPet["breed"]); ?>, <?php echo htmlspecialchars($selectedPet["age"]); ?>)
                    </div>
                <?php } else { ?>
                    <label for="pet_id">Choose Pet to Adopt</label>
                    <select id="pet_id" name="pet_id" required style="width:100%; padding:12px; margin-bottom:20px; border:1px solid #ccc; border-radius:6px;">
                        <option value="">-- Select an Available Pet --</option>
                        <?php foreach ($availablePets as $p) { ?>
                            <option value="<?php echo $p['id']; ?>">
                                <?php echo htmlspecialchars($p['name']); ?> (<?php echo htmlspecialchars($p['type']); ?> - <?php echo htmlspecialchars($p['breed']); ?>)
                            </option>
                        <?php } ?>
                    </select>
                <?php } ?>

                <!-- Full Name -->
                <label for="name">Full Name</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    placeholder="Enter your full name"
                    value="<?php echo htmlspecialchars($userName); ?>"
                    required
                >


                <!-- Email -->
                <label for="email">Email Address</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Enter your email"
                    value="<?php echo htmlspecialchars($userEmail); ?>"
                    required
                >


                <!-- Phone -->
                <label for="phone">Phone Number</label>
                <input
                    type="tel"
                    id="phone"
                    name="phone"
                    placeholder="Enter your 10-digit phone number"
                    required
                >


                <!-- Address -->
                <label for="address">Residential Address</label>
                <textarea
                    id="address"
                    name="address"
                    rows="3"
                    placeholder="Enter your address"
                    required
                ></textarea>


                <!-- Pet Experience -->
                <label>Do you have experience with pets?</label>
                <div class="radio-group" style="margin-bottom:20px;">
                    <label style="margin-right:20px;">
                        <input type="radio" name="experience" value="Yes" checked>
                        Yes
                    </label>

                    <label>
                        <input type="radio" name="experience" value="No">
                        No
                    </label>
                </div>


                <!-- Adoption Reason -->
                <label for="reason">
                    Why would you like to adopt<?php echo $selectedPet ? " " . htmlspecialchars($selectedPet["name"]) : ""; ?>?
                </label>
                <textarea
                    id="reason"
                    name="reason"
                    rows="5"
                    placeholder="Tell us about your home and why you want to adopt this pet"
                    required
                ></textarea>


                <!-- Submit -->
                <button type="submit" class="btn">
                    Submit Application ❤️
                </button>

            </form>

        </div>

    </section>


    <!-- Footer -->
    <footer>

        <h3>🐾 PawNest</h3>

        <p>
            Where Every Pet Finds a Home.
        </p>

        <p class="copyright">
            © 2026 PawNest. All Rights Reserved.
        </p>

    </footer>
    <script src="js/validation.js"></script>
</body>
</html>
