<?php
session_start();
if (isset($_SESSION["user_id"])) {
    header("Location: pets.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Register - PawNest</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <!-- Navigation Bar -->
    <header>

        <div class="logo">
            🐾 PawNest
        </div>

        <nav>
            <a href="index.php">Home</a>
            <a href="pets.php">Pets</a>
            <a href="how-it-works.html">How It Works</a>
            <a href="about-us.html">About Us</a>
            <a href="login.php">Login</a>
        </nav>

    </header>


    <!-- Registration Form -->
    <section class="form-section">

        <div class="form-container">

            <h1>Create Your PawNest Account 🐾</h1>

            <p class="form-intro">
                Join PawNest and start your pet adoption journey.
            </p>


            <form action="php/user-register.php" method="POST" onsubmit="return validateRegister()">

                <label for="name">Full Name</label>

                <input
                    type="text"
                    id="name"
                    name="name"
                    placeholder="Enter your full name"
                    required
                >


                <label for="email">Email Address</label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Enter your email"
                    required
                >


                <label for="phone">Phone Number</label>

                <input
                    type="tel"
                    id="phone"
                    name="phone"
                    placeholder="Enter your phone number"
                    required
                >


                <label for="password">Password</label>

                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Create a password"
                    required
                >


                <label for="confirm-password">Confirm Password</label>

                <input
                    type="password"
                    id="confirm-password"
                    name="confirm_password"
                    placeholder="Confirm your password"
                    required
                >


                <button type="submit" class="btn">
                    Create Account
                </button>

            </form>


            <p class="form-link">
                Already have an account?
                <a href="login.php">Login here</a>
            </p>

        </div>

    </section>


    <!-- Footer -->
    <footer>

        <h3>🐾 PawNest</h3>

        <p>
            Where Every Pet Finds a Home.
        </p>

        <p class="copyright">
            © 2026 PawNest. All Rights Reserved.
        </p>

    </footer>
  <script src="js/validation.js"></script>
</body>
</html>
