<?php
session_start();
require_once __DIR__ . "/php/db.php";

$filterType = trim($_GET["type"] ?? "");

try {
    if ($filterType !== "") {
        $stmt = $conn->prepare("SELECT * FROM pets WHERE type = :type ORDER BY id ASC");
        $stmt->execute([":type" => $filterType]);
    } else {
        $stmt = $conn->query("SELECT * FROM pets ORDER BY id ASC");
    }
    $pets = $stmt->fetchAll();
} catch (PDOException $e) {
    $pets = [];
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Pets - PawNest</title>

    <link rel="stylesheet" href="css/style.css">
    <style>
        .filter-bar {
            max-width: 900px;
            margin: 0 auto 30px;
            display: flex;
            justify-content: center;
            gap: 12px;
            flex-wrap: wrap;
        }
        .filter-btn {
            display: inline-block;
            padding: 8px 18px;
            border-radius: 20px;
            border: 1px solid #e67e22;
            color: #e67e22;
            background: #fff;
            font-weight: 500;
        }
        .filter-btn.active, .filter-btn:hover {
            background: #e67e22;
            color: #fff;
        }
    </style>
</head>

<body>

    <!-- Navigation Bar -->
    <header>

        <div class="logo">
            🐾 PawNest
        </div>

        <nav>
            <a href="index.php">Home</a>
            <a href="pets.php">Pets</a>
            <a href="how-it-works.html">How It Works</a>
            <a href="about-us.html">About Us</a>
            <?php if (isset($_SESSION["user_name"])) { ?>
                <a href="my-applications.php">My Applications</a>
                <span style="color:#e67e22; font-weight:bold; margin-left:15px;">Hi, <?php echo htmlspecialchars($_SESSION["user_name"]); ?>!</span>
                <a href="php/logout.php" style="color:#c0392b;">Logout</a>
            <?php } else { ?>
                <a href="login.php">Login</a>
                <a href="register.php" class="btn" style="padding:7px 15px; color:#fff;">Register</a>
            <?php } ?>
        </nav>

    </header>


    <!-- Page Heading -->
    <section class="page-heading">

        <h1>Find Your Perfect Companion 🐾</h1>

        <p>
            Meet our adorable pets who are waiting
            for a loving forever home.
        </p>

    </section>

    <!-- Filters -->
    <div class="filter-bar">
        <a href="pets.php" class="filter-btn <?php echo empty($filterType) ? 'active' : ''; ?>">All Pets</a>
        <a href="pets.php?type=Dog" class="filter-btn <?php echo ($filterType === 'Dog') ? 'active' : ''; ?>">🐶 Dogs</a>
        <a href="pets.php?type=Cat" class="filter-btn <?php echo ($filterType === 'Cat') ? 'active' : ''; ?>">🐱 Cats</a>
        <a href="pets.php?type=Rabbit" class="filter-btn <?php echo ($filterType === 'Rabbit') ? 'active' : ''; ?>">🐰 Rabbits</a>
    </div>

    <!-- Pet Listing -->
    <section class="pets-section">

        <div class="pet-container">

            <?php if (!empty($pets)) { ?>
                <?php foreach ($pets as $pet) { ?>
                    <div class="pet-card">

                        <div class="pet-image">
                            <?php 
                            $imgFile = !empty($pet["image"]) ? "images/" . $pet["image"] : "";
                            if ($imgFile && file_exists(__DIR__ . "/" . $imgFile)) {
                                echo '<img src="' . htmlspecialchars($imgFile) . '" alt="' . htmlspecialchars($pet["name"]) . '">';
                            } else {
                                echo ($pet["type"] === "Cat") ? "🐱" : (($pet["type"] === "Rabbit") ? "🐰" : "🐶");
                            }
                            ?>
                        </div>

                        <h3><?php echo htmlspecialchars($pet["name"]); ?></h3>

                        <p><?php echo htmlspecialchars($pet["breed"]); ?> • <?php echo htmlspecialchars($pet["age"]); ?></p>

                        <p>
                            <strong>Gender:</strong> <?php echo htmlspecialchars($pet["gender"]); ?>
                        </p>

                        <p>
                            <span class="pet-status <?php echo strtolower($pet['status']); ?>-status">
                                <?php echo htmlspecialchars($pet["status"]); ?>
                            </span>
                        </p>

                        <a href="pet-details.php?id=<?php echo $pet["id"]; ?>" class="card-btn">
                            View Details
                        </a>

                    </div>
                <?php } ?>
            <?php } else { ?>
                <div style="grid-column: 1/-1; text-align: center; padding: 40px;">
                    <h3>No pets found in this category.</h3>
                    <p><a href="pets.php" class="btn" style="margin-top:15px;">View All Pets</a></p>
                </div>
            <?php } ?>

        </div>

    </section>


    <!-- Footer -->
    <footer>

        <h3>🐾 PawNest</h3>

        <p>
            Where Every Pet Finds a Home.
        </p>

        <p class="copyright">
            © 2026 PawNest. All Rights Reserved.
        </p>

    </footer>

</body>
</html>
