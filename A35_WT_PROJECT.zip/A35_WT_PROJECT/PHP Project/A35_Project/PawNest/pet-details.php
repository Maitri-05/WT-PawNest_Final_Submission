<?php
session_start();
require_once __DIR__ . "/php/db.php";

$pet_id = (int)($_GET["id"] ?? 0);

if ($pet_id <= 0) {
    header("Location: pets.php");
    exit;
}

try {
    $stmt = $conn->prepare("SELECT * FROM pets WHERE id = :id");
    $stmt->execute([":id" => $pet_id]);
    $pet = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$pet) {
        die("Pet not found. <a href='pets.php'>Browse all pets</a>");
    }
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo htmlspecialchars($pet["name"]); ?> - PawNest</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <!-- Navigation Bar -->
    <header>

        <div class="logo">
            🐾 PawNest
        </div>

        <nav>
            <a href="index.php">Home</a>
            <a href="pets.php">Pets</a>
            <a href="how-it-works.html">How It Works</a>
            <a href="about-us.html">About Us</a>
            <?php if (isset($_SESSION["user_name"])) { ?>
                <a href="my-applications.php">My Applications</a>
                <span style="color:#e67e22; font-weight:bold; margin-left:15px;">Hi, <?php echo htmlspecialchars($_SESSION["user_name"]); ?>!</span>
                <a href="php/logout.php" style="color:#c0392b;">Logout</a>
            <?php } else { ?>
                <a href="login.php">Login</a>
                <a href="register.php" class="btn" style="padding:7px 15px; color:#fff;">Register</a>
            <?php } ?>
        </nav>

    </header>


    <!-- Pet Details -->
    <section class="pet-details">

        <div class="details-image">
            <?php 
            $imgFile = !empty($pet["image"]) ? "images/" . $pet["image"] : "";
            if ($imgFile && file_exists(__DIR__ . "/" . $imgFile)) {
                echo '<img src="' . htmlspecialchars($imgFile) . '" alt="' . htmlspecialchars($pet["name"]) . '">';
            } else {
                echo ($pet["type"] === "Cat") ? "🐱" : (($pet["type"] === "Rabbit") ? "🐰" : "🐶");
            }
            ?>
        </div>


        <div class="details-content">

            <h1>Meet <?php echo htmlspecialchars($pet["name"]); ?> 🐾</h1>

            <p class="pet-intro">
                <?php echo htmlspecialchars($pet["name"]); ?> is a lovely <?php echo htmlspecialchars($pet["breed"]); ?> looking for a caring forever home.
            </p>


            <div class="pet-info">

                <div>
                    <strong>Type</strong>
                    <p><?php echo htmlspecialchars($pet["type"]); ?></p>
                </div>

                <div>
                    <strong>Breed</strong>
                    <p><?php echo htmlspecialchars($pet["breed"]); ?></p>
                </div>

                <div>
                    <strong>Age</strong>
                    <p><?php echo htmlspecialchars($pet["age"]); ?></p>
                </div>

                <div>
                    <strong>Gender</strong>
                    <p><?php echo htmlspecialchars($pet["gender"]); ?></p>
                </div>

            </div>


            <h3>About <?php echo htmlspecialchars($pet["name"]); ?></h3>

            <p class="description">
                <?php echo nl2br(htmlspecialchars($pet["description"])); ?>
            </p>


            <p class="available" style="margin:20px 0;">
                <span class="pet-status <?php echo strtolower($pet['status']); ?>-status">
                    ● <?php echo htmlspecialchars($pet["status"]); ?>
                </span>
            </p>


            <?php if ($pet["status"] === "Available") { ?>
                <a href="adoption.php?pet_id=<?php echo $pet["id"]; ?>" class="btn">
                    Adopt <?php echo htmlspecialchars($pet["name"]); ?> ❤️
                </a>
            <?php } else { ?>
                <p style="color:#888; font-style:italic;">
                    This pet currently has status: <strong><?php echo htmlspecialchars($pet["status"]); ?></strong>
                </p>
            <?php } ?>

            <p style="margin-top:20px;">
                <a href="pets.php" style="color:#e67e22;">← Back to All Pets</a>
            </p>

        </div>

    </section>


    <!-- Footer -->
    <footer>

        <h3>🐾 PawNest</h3>

        <p>
            Where Every Pet Finds a Home.
        </p>

        <p class="copyright">
            © 2026 PawNest. All Rights Reserved.
        </p>

    </footer>

</body>
</html>
