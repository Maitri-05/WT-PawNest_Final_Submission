<?php
session_start();
require_once __DIR__ . "/php/db.php";

$userId = $_SESSION["user_id"] ?? null;
$userEmail = $_SESSION["user_email"] ?? null;

$searchEmail = trim($_GET["email"] ?? ($userEmail ?? ""));

try {
    if (!empty($searchEmail)) {
        $sql = "SELECT a.*, p.name AS pet_name, p.breed AS pet_breed, p.image AS pet_image, p.type AS pet_type 
                FROM applications a 
                LEFT JOIN pets p ON a.pet_id = p.id 
                WHERE a.email = :email OR a.user_id = :uid
                ORDER BY a.id DESC";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ":email" => $searchEmail,
            ":uid" => $userId ?? 0
        ]);
    } else {
        // Show recent applications if no filter
        $sql = "SELECT a.*, p.name AS pet_name, p.breed AS pet_breed, p.image AS pet_image, p.type AS pet_type 
                FROM applications a 
                LEFT JOIN pets p ON a.pet_id = p.id 
                ORDER BY a.id DESC";
        $stmt = $conn->query($sql);
    }
    $applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $applications = [];
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>My Applications - PawNest</title>
</head>

<body>

    <!-- HEADER -->
    <header>
        <div class="logo">
            PawNest 🐾
        </div>

        <nav>
            <a href="index.php">Home</a>
            <a href="pets.php">Pets</a>
            <a href="how-it-works.html">How It Works</a>
            <a href="about-us.html">About Us</a>
            <?php if (isset($_SESSION["user_name"])) { ?>
                <a href="my-applications.php">My Applications</a>
                <span style="color:#e67e22; font-weight:bold; margin-left:15px;">Hi, <?php echo htmlspecialchars($_SESSION["user_name"]); ?>!</span>
                <a href="php/logout.php" style="color:#c0392b;">Logout</a>
            <?php } else { ?>
                <a href="login.php">Login</a>
                <a href="register.php" class="btn" style="padding:7px 15px; color:#fff;">Register</a>
            <?php } ?>
        </nav>
    </header>


    <!-- PAGE HEADING -->
    <section class="page-heading">
        <h1>My Adoption Applications 📝</h1>
        <p>Keep track of your pet adoption applications directly from the database.</p>
    </section>


    <!-- USER INFO & SEARCH -->
    <section class="dashboard-section">

        <div class="welcome-box">
            <h2>Welcome<?php echo isset($_SESSION["user_name"]) ? ", " . htmlspecialchars($_SESSION["user_name"]) : ", Pet Lover"; ?>! 🐾</h2>
            <p>
                Below are the adoption applications recorded in our database.
            </p>
            
            <!-- Lookup by email form if guest -->
            <form method="GET" action="my-applications.php" style="margin-top:15px; display:flex; gap:10px; max-width:500px;">
                <input type="email" name="email" placeholder="Filter by your email address..." value="<?php echo htmlspecialchars($searchEmail); ?>" style="flex:1; padding:10px; border:1px solid #ccc; border-radius:6px;">
                <button type="submit" class="btn" style="padding:10px 18px;">Search</button>
                <?php if ($searchEmail) { ?>
                    <a href="my-applications.php" class="btn" style="background:#888; padding:10px 14px;">Show All</a>
                <?php } ?>
            </form>
        </div>


        <!-- APPLICATIONS LIST -->
        <h2 class="dashboard-title">Adoption Applications</h2>

        <div class="application-container">

            <?php if (!empty($applications)) { ?>
                <?php foreach ($applications as $app) { ?>
                    <div class="application-card" style="margin-bottom:20px;">

                        <div class="application-pet">
                            <?php 
                            $imgFile = !empty($app["pet_image"]) ? "images/" . $app["pet_image"] : "";
                            if ($imgFile && file_exists(__DIR__ . "/" . $imgFile)) {
                                echo '<img src="' . htmlspecialchars($imgFile) . '" alt="' . htmlspecialchars($app["pet_name"] ?? 'Pet') . '">';
                            } else {
                                echo ($app["pet_type"] === "Cat") ? "🐱" : (($app["pet_type"] === "Rabbit") ? "🐰" : "🐶");
                            }
                            ?>
                        </div>

                        <div class="application-details">
                            <h3><?php echo htmlspecialchars($app["pet_name"] ?? "Pet #" . $app["pet_id"]); ?></h3>

                            <p><strong>Applicant:</strong> <?php echo htmlspecialchars($app["applicant_name"]); ?> (<?php echo htmlspecialchars($app["email"]); ?>)</p>
                            <p><strong>Breed / Type:</strong> <?php echo htmlspecialchars($app["pet_breed"] ?? 'N/A'); ?> (<?php echo htmlspecialchars($app["pet_type"] ?? ''); ?>)</p>
                            <p><strong>Application Date:</strong> <?php echo htmlspecialchars(date("d M Y, h:i A", strtotime($app["created_at"]))); ?></p>
                            <p><strong>Pet Experience:</strong> <?php echo htmlspecialchars($app["experience"]); ?></p>
                            <p><strong>Reason:</strong> <em>"<?php echo htmlspecialchars($app["reason"]); ?>"</em></p>

                            <p>
                                <strong>Status:</strong>
                                <span class="application-status <?php echo strtolower($app['status']); ?>">
                                    <?php echo htmlspecialchars($app["status"]); ?>
                                </span>
                            </p>
                        </div>

                    </div>
                <?php } ?>
            <?php } else { ?>
                <div style="background:#fff; padding:40px; text-align:center; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.06);">
                    <span style="font-size:50px;">📋</span>
                    <h3 style="margin:15px 0; color:#555;">No applications found.</h3>
                    <p style="color:#777; margin-bottom:20px;">Ready to find your companion?</p>
                    <a href="pets.php" class="btn">Browse Available Pets</a>
                </div>
            <?php } ?>

        </div>

    </section>


    <!-- CTA -->
    <section class="cta">
        <h2>Looking for Another Companion? 🐾</h2>
        <p>There are many pets waiting for their forever home.</p>
        <a href="pets.php" class="btn">Browse Available Pets</a>
    </section>


    <!-- FOOTER -->
    <footer>
        <h3>PawNest 🐾</h3>
        <p>Where Every Pet Finds a Home.</p>
        <p class="copyright">© 2026 PawNest. All Rights Reserved.</p>
    </footer>

</body>
</html>
