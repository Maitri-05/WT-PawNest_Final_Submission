<?php
require_once __DIR__ . "/php/db.php";
echo "PHP and MySQL Database are working perfectly!";
