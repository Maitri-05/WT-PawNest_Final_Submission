-- PawNest Pet Adoption Database Schema & Seed Data
-- Import this file into phpMyAdmin or MySQL Workbench

CREATE DATABASE IF NOT EXISTS `pawnest` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `pawnest`;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `applications`;
DROP TABLE IF EXISTS `pets`;
DROP TABLE IF EXISTS `users`;
SET FOREIGN_KEY_CHECKS = 1;

-- ========================================================
-- Table: users
-- ========================================================
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `phone` VARCHAR(20) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(20) NOT NULL DEFAULT 'user',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed Users:
-- Admin password is: admin123
-- Rahul password is: user123
INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `role`) VALUES
(2, 'admin', 'admin@gmail.com', '7896541236', 'admin123', 'admin'),
(3, 'Rahul Sharma', 'rahul@gmail.com', '9876543210', 'user123', 'user');

-- ========================================================
-- Table: pets
-- Matches the screenshots from the Requirements document
-- ========================================================
CREATE TABLE `pets` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `type` VARCHAR(50) NOT NULL,
  `breed` VARCHAR(100) NOT NULL,
  `age` VARCHAR(50) NOT NULL,
  `gender` VARCHAR(20) NOT NULL,
  `description` TEXT,
  `image` VARCHAR(255) DEFAULT NULL,
  `status` VARCHAR(50) NOT NULL DEFAULT 'Available',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `pets` (`id`, `name`, `type`, `breed`, `age`, `gender`, `description`, `image`, `status`) VALUES
(1, 'Bruno', 'Dog', 'Labrador', '3', 'Male', 'playful n funnn', 'bruno.webp', 'Available'),
(3, 'Simba', 'Cat', 'British Longhair', '3', 'Male', 'smart n full of energyyy.', 'simba.webp', 'Available'),
(4, 'Sweety', 'Cat', 'xyz', '3', 'Female', 'cute n fun loving', 'sweety.jpg', 'Available'),
(5, 'Luna', 'Cat', 'Persian Cat', '1 Year', 'Female', 'Calm and affectionate Persian cat who loves quiet afternoons.', 'luna.webp', 'Available'),
(6, 'Snowy', 'Rabbit', 'Dutch Rabbit', '8 Months', 'Female', 'Gentle, curious, and loves eating fresh greens.', 'snowy.webp', 'Available'),
(7, 'Rocky', 'Dog', 'Beagle', '3 Years', 'Male', 'Energetic Beagle who loves playing outdoors and going on walks.', 'rocky.webp', 'Available');

-- ========================================================
-- Table: applications
-- For Adoption Applications
-- ========================================================
CREATE TABLE `applications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NULL,
  `pet_id` INT NOT NULL,
  `applicant_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `address` TEXT NOT NULL,
  `experience` VARCHAR(10) NOT NULL,
  `reason` TEXT NOT NULL,
  `status` VARCHAR(50) NOT NULL DEFAULT 'Pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`pet_id`) REFERENCES `pets`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `applications` (`id`, `user_id`, `pet_id`, `applicant_name`, `email`, `phone`, `address`, `experience`, `reason`, `status`, `created_at`) VALUES
(1, 3, 1, 'Rahul Sharma', 'rahul@gmail.com', '9876543210', '101 Palm Grove, Mumbai', 'Yes', 'I have loved dogs since childhood and have a large garden for Bruno to play.', 'Pending', '2026-08-20 10:30:00'),
(2, NULL, 5, 'Priya Mehta', 'priya@gmail.com', '9812345678', '402 Skyline Apts, Pune', 'Yes', 'Looking for a calm, friendly cat companion for our apartment.', 'Approved', '2026-08-18 14:15:00'),
(3, NULL, 6, 'Aarav Patel', 'aarav@gmail.com', '9823456789', '12 Rose Villa, Ahmedabad', 'No', 'First time pet parent looking to adopt a gentle rabbit.', 'Rejected', '2026-08-15 09:45:00');
