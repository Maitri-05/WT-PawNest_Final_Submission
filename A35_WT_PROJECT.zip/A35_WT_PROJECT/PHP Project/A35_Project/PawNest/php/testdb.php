<?php
// PawNest Database & CRUD Verification Test
require_once __DIR__ . "/db.php";

echo "<!DOCTYPE html><html><head><title>Database Status Test</title>";
echo "<style>body{font-family:Arial,sans-serif;background:#fffaf5;padding:30px;} .card{background:#fff;padding:25px;border-radius:10px;box-shadow:0 3px 10px rgba(0,0,0,0.1);max-width:700px;margin:auto;} table{width:100%;border-collapse:collapse;margin:15px 0;} th,td{border:1px solid #ddd;padding:8px 12px;text-align:left;} th{background:#fff0df;} .badge{background:#27ae60;color:#fff;padding:4px 8px;border-radius:4px;font-size:12px;}</style></head><body>";

echo "<div class='card'>";
echo "<h2>🐾 PawNest Database Connectivity Test</h2>";
echo "<p><span class='badge'>Connected</span> Successfully connected to MySQL database: <strong>pawnest</strong></p>";

try {
    // 1. Check Tables
    $tables = $conn->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "<h3>Tables in 'pawnest':</h3><ul>";
    foreach ($tables as $t) {
        $count = $conn->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
        echo "<li><strong>$t</strong>: $count records</li>";
    }
    echo "</ul>";

    // 2. Sample Pets
    echo "<h3>Pets in Database:</h3>";
    $pets = $conn->query("SELECT id, name, type, breed, age, gender, status FROM pets")->fetchAll(PDO::FETCH_ASSOC);
    if (!empty($pets)) {
        echo "<table><tr><th>ID</th><th>Name</th><th>Type</th><th>Breed</th><th>Age</th><th>Gender</th><th>Status</th></tr>";
        foreach ($pets as $p) {
            echo "<tr><td>{$p['id']}</td><td>{$p['name']}</td><td>{$p['type']}</td><td>{$p['breed']}</td><td>{$p['age']}</td><td>{$p['gender']}</td><td>{$p['status']}</td></tr>";
        }
        echo "</table>";
    }

    // 3. Sample Users
    echo "<h3>Users in Database:</h3>";
    $users = $conn->query("SELECT id, name, email, phone, role FROM users")->fetchAll(PDO::FETCH_ASSOC);
    if (!empty($users)) {
        echo "<table><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Role</th></tr>";
        foreach ($users as $u) {
            echo "<tr><td>{$u['id']}</td><td>{$u['name']}</td><td>{$u['email']}</td><td>{$u['phone']}</td><td>{$u['role']}</td></tr>";
        }
        echo "</table>";
    }

    echo "<p style='margin-top:20px;'><a href='../index.php'>Go to PawNest Website</a> | <a href='../admin/dashboard.php'>Go to Admin Panel</a></p>";

} catch (PDOException $e) {
    echo "<p style='color:red;'>Query error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

echo "</div></body></html>";
