<?php
// Forward to admin/delete-pet.php
$queryString = $_SERVER["QUERY_STRING"] ? "?" . $_SERVER["QUERY_STRING"] : "";
header("Location: ../admin/delete-pet.php" . $queryString);
exit;
