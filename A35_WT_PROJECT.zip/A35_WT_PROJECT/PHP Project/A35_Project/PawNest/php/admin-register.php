<?php
session_start();
require_once __DIR__ . "/db.php";

// Only allow POST form submissions
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../admin/admin-register.html");
    exit;
}

$name = trim($_POST["name"] ?? "");
$email = trim($_POST["email"] ?? "");
$phone = trim($_POST["phone"] ?? "");
$password = $_POST["password"] ?? "";
$confirm_password = $_POST["confirm_password"] ?? "";

// Validate required fields
if ($name === "" || $email === "" || $phone === "" || $password === "" || $confirm_password === "") {
    exit("All fields are required. <a href='../admin/admin-register.html'>Try again</a>");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    exit("Please enter a valid email address. <a href='../admin/admin-register.html'>Try again</a>");
}

if ($password !== $confirm_password) {
    exit("Passwords do not match. <a href='../admin/admin-register.html'>Try again</a>");
}

try {
    // Check if email already registered
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
    $stmt->execute([":email" => $email]);

    if ($stmt->fetch()) {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Registration Error - PawNest</title>
            <link rel="stylesheet" href="../css/style.css">
        </head>
        <body>
            <section class="admin-form-section" style="max-width:500px;margin:80px auto;text-align:center;">
                <h2>⚠️ Email Already Exists</h2>
                <p>An account with email <strong><?php echo htmlspecialchars($email); ?></strong> is already registered.</p>
                <p><a class="btn" href="../admin/admin-login.html">Login as Admin</a></p>
            </section>
        </body>
        </html>
        <?php
        exit;
    }

    // Hash the password securely
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert the administrator
    $stmt = $conn->prepare(
        "INSERT INTO users (name, email, phone, password, role) VALUES (:name, :email, :phone, :password, 'admin')"
    );
    $stmt->execute([
        ":name" => $name,
        ":email" => $email,
        ":phone" => $phone,
        ":password" => $hashed_password
    ]);

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Admin Registered - PawNest</title>
        <link rel="stylesheet" href="../css/style.css">
    </head>
    <body>
        <section class="admin-form-section" style="max-width:500px;margin:80px auto;text-align:center;">
            <h2>🎉 Admin Account Created!</h2>
            <p>Admin <strong><?php echo htmlspecialchars($name); ?></strong> has been saved to the database.</p>
            <p><a class="btn" href="../admin/admin-login.html">Proceed to Admin Login</a></p>
        </section>
    </body>
    </html>
    <?php

} catch (PDOException $e) {
    error_log("Admin registration error: " . $e->getMessage());
    http_response_code(500);
    exit("Registration failed due to a server error: " . htmlspecialchars($e->getMessage()));
}
