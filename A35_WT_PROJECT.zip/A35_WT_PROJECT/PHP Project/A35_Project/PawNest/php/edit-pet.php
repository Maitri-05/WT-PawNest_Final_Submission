<?php
// Redirect to admin/edit-pet.php
$queryString = $_SERVER["QUERY_STRING"] ? "?" . $_SERVER["QUERY_STRING"] : "";
header("Location: ../admin/edit-pet.php" . $queryString);
exit;
