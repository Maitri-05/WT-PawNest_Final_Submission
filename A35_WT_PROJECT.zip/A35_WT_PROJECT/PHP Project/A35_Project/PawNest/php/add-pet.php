<?php
session_start();

require_once __DIR__ . "/db.php";

// Accept POST requests only
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../admin/add-pet.html");
    exit;
}

// Read form data safely
$name = trim($_POST["name"] ?? "");
$type = trim($_POST["type"] ?? "");
$breed = trim($_POST["breed"] ?? "");
$age = trim($_POST["age"] ?? "");
$gender = trim($_POST["gender"] ?? "");
$description = trim($_POST["description"] ?? "");
$image = trim($_POST["image"] ?? "");
$status = trim($_POST["status"] ?? "Available");

// Validate required fields
if ($name === "" || $type === "" || $breed === "" || $age === "" || $gender === "") {
    exit("Please fill in all required fields. <a href='../admin/add-pet.html'>Go back</a>");
}

// Clean up image filename if provided
if ($image !== "") {
    $image = basename($image);
}

try {
    $sql = "INSERT INTO pets (name, type, breed, age, gender, description, image, status)
            VALUES (:name, :type, :breed, :age, :gender, :description, :image, :status)";

    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ":name" => $name,
        ":type" => $type,
        ":breed" => $breed,
        ":age" => $age,
        ":gender" => $gender,
        ":description" => $description,
        ":image" => $image !== "" ? $image : null,
        ":status" => $status
    ]);

    // Redirect to manage pets with success parameter
    header("Location: ../admin/manage-pets.php?success=added");
    exit;

} catch (PDOException $e) {
    error_log("Add pet database error: " . $e->getMessage());
    http_response_code(500);
    exit("Unable to save the pet to database: " . htmlspecialchars($e->getMessage()) . " <a href='../admin/add-pet.html'>Try again</a>");
}
