<?php
session_start();

require_once __DIR__ . "/db.php";

// Accept only POST form submissions
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../register.html");
    exit;
}

$name = trim($_POST["name"] ?? "");
$email = trim($_POST["email"] ?? "");
$phone = trim($_POST["phone"] ?? "");
$password = $_POST["password"] ?? "";
$confirmPassword = $_POST["confirm_password"] ?? "";

// Basic validation
if ($name === "" || $email === "" || $phone === "" || $password === "") {
    die("All fields are required. <a href='../register.html'>Go back</a>");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Invalid email format. <a href='../register.html'>Go back</a>");
}

if ($password !== $confirmPassword) {
    die("Passwords do not match. <a href='../register.html'>Go back</a>");
}

try {
    // Check if email already exists
    $checkStmt = $conn->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
    $checkStmt->execute([":email" => $email]);
    if ($checkStmt->fetch()) {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Registration Error - PawNest</title>
            <link rel="stylesheet" href="../css/style.css">
        </head>
        <body>
            <section class="form-section">
                <div class="form-container" style="text-align:center;">
                    <h2>⚠️ Email Already Registered</h2>
                    <p style="margin:20px 0; color:#555;">An account with this email address already exists.</p>
                    <a class="btn" href="../login.html">Login Instead</a>
                    <a class="btn" style="background:#888;margin-left:10px;" href="../register.html">Try Another Email</a>
                </div>
            </section>
        </body>
        </html>
        <?php
        exit;
    }

    // Hash password securely
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $insertStmt = $conn->prepare(
        "INSERT INTO users (name, email, phone, password, role) VALUES (:name, :email, :phone, :password, 'user')"
    );
    $insertStmt->execute([
        ":name" => $name,
        ":email" => $email,
        ":phone" => $phone,
        ":password" => $hashedPassword
    ]);

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Account Created - PawNest</title>
        <link rel="stylesheet" href="../css/style.css">
    </head>
    <body>
        <section class="form-section">
            <div class="form-container" style="text-align:center;">
                <h2>🎉 Welcome to PawNest, <?php echo htmlspecialchars($name); ?>!</h2>
                <p style="margin:20px 0; color:#555;">Your account has been registered successfully.</p>
                <a class="btn" href="../login.html">Click Here to Login</a>
            </div>
        </section>
    </body>
    </html>
    <?php

} catch (PDOException $e) {
    error_log("User registration error: " . $e->getMessage());
    die("Error saving account to database: " . $e->getMessage());
}
