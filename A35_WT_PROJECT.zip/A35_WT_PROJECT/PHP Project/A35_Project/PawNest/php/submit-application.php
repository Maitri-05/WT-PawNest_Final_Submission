<?php
session_start();
require_once __DIR__ . "/db.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../pets.php");
    exit;
}

$pet_id = (int)($_POST["pet_id"] ?? 0);
$name = trim($_POST["name"] ?? "");
$email = trim($_POST["email"] ?? "");
$phone = trim($_POST["phone"] ?? "");
$address = trim($_POST["address"] ?? "");
$experience = trim($_POST["experience"] ?? "No");
$reason = trim($_POST["reason"] ?? "");
$user_id = $_SESSION["user_id"] ?? null;

if ($pet_id <= 0 || $name === "" || $email === "" || $phone === "" || $address === "" || $reason === "") {
    die("Please fill in all required application fields. <a href='javascript:history.back()'>Go back</a>");
}

try {
    // Check if pet exists
    $petStmt = $conn->prepare("SELECT name FROM pets WHERE id = :id");
    $petStmt->execute([":id" => $pet_id]);
    $pet = $petStmt->fetch(PDO::FETCH_ASSOC);

    if (!$pet) {
        die("Selected pet was not found. <a href='../pets.php'>Browse pets</a>");
    }

    // Insert into applications table
    $sql = "INSERT INTO applications 
            (user_id, pet_id, applicant_name, email, phone, address, experience, reason, status)
            VALUES 
            (:user_id, :pet_id, :applicant_name, :email, :phone, :address, :experience, :reason, 'Pending')";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ":user_id" => $user_id,
        ":pet_id" => $pet_id,
        ":applicant_name" => $name,
        ":email" => $email,
        ":phone" => $phone,
        ":address" => $address,
        ":experience" => $experience,
        ":reason" => $reason
    ]);

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Application Submitted - PawNest</title>
        <link rel="stylesheet" href="../css/style.css">
    </head>
    <body>
        <header>
            <div class="logo">PawNest 🐾</div>
            <nav>
                <a href="../index.php">Home</a>
                <a href="../pets.php">Pets</a>
                <a href="../my-applications.php">My Applications</a>
            </nav>
        </header>

        <section class="page-heading">
            <h1>Application Submitted Successfully! 🎉</h1>
            <p>Thank you, <strong><?php echo htmlspecialchars($name); ?></strong>! Your application to adopt <strong><?php echo htmlspecialchars($pet["name"]); ?></strong> has been sent to our team.</p>
        </section>

        <section style="text-align:center; padding: 40px 20px;">
            <div style="max-width:600px; margin:auto; background:#fff; padding:35px; border-radius:12px; box-shadow:0 3px 12px rgba(0,0,0,0.08);">
                <span style="font-size:70px;">🐾</span>
                <h2 style="color:#4a2c20; margin:15px 0;">We have received your application</h2>
                <p style="color:#666; line-height:1.6; margin-bottom:25px;">
                    Our shelter managers will review your details and contact you via email at <strong><?php echo htmlspecialchars($email); ?></strong> or phone at <strong><?php echo htmlspecialchars($phone); ?></strong>.
                </p>
                <a class="btn" href="../my-applications.php">View My Applications</a>
                <a class="btn" style="background:#555; margin-left:10px;" href="../pets.php">Browse More Pets</a>
            </div>
        </section>

        <footer>
            <h3>PawNest 🐾</h3>
            <p>Where Every Pet Finds a Home.</p>
            <p class="copyright">© 2026 PawNest. All Rights Reserved.</p>
        </footer>
    </body>
    </html>
    <?php

} catch (PDOException $e) {
    error_log("Error saving application: " . $e->getMessage());
    die("Database error submitting application: " . $e->getMessage());
}
