<?php
require_once __DIR__ . "/db.php";
echo "Database connection successful! PawNest backend is connected to MySQL.";
