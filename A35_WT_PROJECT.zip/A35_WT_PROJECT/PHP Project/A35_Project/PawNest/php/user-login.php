<?php
session_start();

require_once __DIR__ . "/db.php";

// Accept only POST form submissions
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../login.html");
    exit;
}

$email = trim($_POST["email"] ?? "");
$password = $_POST["password"] ?? "";

if ($email === "" || $password === "") {
    header("Location: ../login.html?error=empty");
    exit;
}

try {
    $sql = "SELECT id, name, email, password, role FROM users WHERE email = :email LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->execute([":email" => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    $passwordValid = false;
    if ($user) {
        if (password_verify($password, $user["password"]) || $password === $user["password"]) {
            $passwordValid = true;
        }
    }

    if (!$passwordValid) {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Login Error - PawNest</title>
            <link rel="stylesheet" href="../css/style.css">
        </head>
        <body>
            <header>
                <div class="logo">🐾 PawNest</div>
                <nav><a href="../index.php">Home</a><a href="../login.html">Login</a></nav>
            </header>
            <section class="form-section">
                <div class="form-container" style="text-align:center;">
                    <h2>⚠️ Invalid Credentials</h2>
                    <p style="margin:20px 0; color:#555;">Incorrect email or password entered.</p>
                    <a class="btn" href="../login.html">Try Again</a>
                    <p style="margin-top:20px;"><a href="../register.html">Don't have an account? Register here</a></p>
                </div>
            </section>
        </body>
        </html>
        <?php
        exit;
    }

    // Login successful
    session_regenerate_id(true);
    $_SESSION["user_id"] = $user["id"];
    $_SESSION["user_name"] = $user["name"];
    $_SESSION["user_email"] = $user["email"];
    $_SESSION["user_role"] = $user["role"];

    if ($user["role"] === "admin") {
        $_SESSION["admin_id"] = $user["id"];
        $_SESSION["admin_name"] = $user["name"];
        $_SESSION["admin_email"] = $user["email"];
        $_SESSION["admin_role"] = "admin";
        header("Location: ../admin/dashboard.php");
        exit;
    }

    header("Location: ../pets.php?login=success");
    exit;

} catch (PDOException $e) {
    error_log("User login error: " . $e->getMessage());
    die("A database error occurred. Please try again later.");
}
