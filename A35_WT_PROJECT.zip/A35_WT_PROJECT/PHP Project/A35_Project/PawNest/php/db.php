<?php
// ========================================================
// PawNest - Database Connection Configuration
// ========================================================

$host = "127.0.0.1";
$port = 3306;
$dbname = "pawnest";
$username = "root";

// Standard local MySQL passwords to try: "root", then empty "" (standard in XAMPP)
$passwordsToTry = ["root", "", "admin"];

$conn = null;
$connectionError = null;

foreach ($passwordsToTry as $pwd) {
    try {
        $conn = new PDO(
            "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4",
            $username,
            $pwd,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        );
        break; // Successfully connected!
    } catch (PDOException $e) {
        $connectionError = $e->getMessage();
    }
}

if (!$conn) {
    error_log("Database connection error: " . $connectionError);
    // User-friendly diagnostic message
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Database Connection Error - PawNest</title>
        <style>
            body { font-family: Arial, sans-serif; background: #fffaf5; padding: 40px 20px; }
            .error-card { max-width: 600px; margin: auto; background: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); border-top: 5px solid #e74c3c; }
            h2 { color: #c0392b; margin-top: 0; }
            p { color: #555; line-height: 1.6; }
            pre { background: #f8f9fa; padding: 12px; border-radius: 6px; overflow-x: auto; color: #333; font-size: 13px; }
            .steps { background: #fff8f0; border-left: 4px solid #e67e22; padding: 15px; margin: 20px 0; }
        </style>
    </head>
    <body>
        <div class="error-card">
            <h2>⚠️ Database Connection Error</h2>
            <p>Could not connect to the database <strong>pawnest</strong>.</p>
            <pre><?php echo htmlspecialchars($connectionError); ?></pre>
            <div class="steps">
                <strong>How to fix:</strong>
                <ol>
                    <li>Start <strong>MySQL</strong> in your XAMPP / WAMP / MySQL control panel.</li>
                    <li>Ensure the database <code>pawnest</code> is created and imported using <code>pawnest.sql</code>.</li>
                </ol>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}
