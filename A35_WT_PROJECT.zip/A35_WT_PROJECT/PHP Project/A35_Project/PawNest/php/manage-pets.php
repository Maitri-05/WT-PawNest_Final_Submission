<?php
// Redirect to admin/manage-pets.php
$queryString = $_SERVER["QUERY_STRING"] ? "?" . $_SERVER["QUERY_STRING"] : "";
header("Location: ../admin/manage-pets.php" . $queryString);
exit;
