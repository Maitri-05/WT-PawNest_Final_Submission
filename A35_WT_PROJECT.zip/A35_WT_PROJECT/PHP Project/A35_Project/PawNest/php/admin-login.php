<?php
session_start();

require_once __DIR__ . "/db.php";

// Accept only form submissions
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../admin/admin-login.html");
    exit;
}

// Read and validate form data
$email = trim($_POST["email"] ?? "");
$password = $_POST["password"] ?? "";

if ($email === "" || $password === "") {
    http_response_code(400);
    exit("Please enter both email and password. <a href='../admin/admin-login.html'>Try again</a>");
}

try {
    // Find an admin account by email
    $sql = "SELECT id, name, email, password, role
            FROM users
            WHERE email = :email

            
              AND role = 'admin'
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ":email" => $email
    ]);

    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verify the stored password (handles both password_hash and plain-text fallback)
    $passwordValid = false;
    if ($admin) {
        if (password_verify($password, $admin["password"]) || $password === $admin["password"]) {
            $passwordValid = true;
        }
    }

    if (!$passwordValid) {
        http_response_code(401);
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Login Failed - PawNest</title>
            <link rel="stylesheet" href="../css/style.css">
        </head>
        <body>
            <section class="admin-form-section" style="max-width:500px;margin:80px auto;text-align:center;">
                <h2>⚠️ Login Failed</h2>
                <p>Invalid admin email or password.</p>
                <p><a class="btn" href="../admin/admin-login.html">Try Again</a></p>
            </section>
        </body>
        </html>
        <?php
        exit;
    }

    // Prevent session fixation
    session_regenerate_id(true);

    // Store authenticated admin details in the session
    $_SESSION["admin_id"] = $admin["id"];
    $_SESSION["admin_name"] = $admin["name"];
    $_SESSION["admin_email"] = $admin["email"];
    $_SESSION["admin_role"] = $admin["role"];

    // Redirect to the admin dashboard
    header("Location: ../admin/dashboard.php");
    exit;

} catch (PDOException $e) {
    error_log("Admin login database error: " . $e->getMessage());
    http_response_code(500);
    exit("A server error occurred. Please try again later.");
}
