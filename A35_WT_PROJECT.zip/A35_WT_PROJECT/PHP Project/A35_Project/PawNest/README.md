# PawNest - Pet Adoption Management System

A full-stack PHP & MySQL Web Application implementing end-to-end database connectivity and complete CRUD (Create, Read, Update, Delete) operations.

---

## 🗄️ Database Setup (`pawnest`)

1. Open **phpMyAdmin** (`http://localhost/phpmyadmin`) or **MySQL Workbench**.
2. Create a new database named `pawnest` or simply import the provided SQL file:
   - File location: `pawnest.sql` (or `A35_Project/PawNest/pawnest.sql`).
3. The SQL script will create the following tables and seed data:
   - **`users`**: User and administrator accounts.
   - **`pets`**: Pets available for adoption (contains Bruno, Simba, Sweety matching the requirements document).
   - **`applications`**: Adoption requests submitted by users.

### Default Login Credentials:
- **Admin Login:**
  - Email: `admin@gmail.com`
  - Password: `admin123`
- **User Login:**
  - Email: `rahul@gmail.com`
  - Password: `user123`

---

## 🚀 How to Run the Project

1. Copy the `A35_Project` folder (or `PawNest`) into your web server directory:
   - For XAMPP: `C:\xampp\htdocs\`
   - For WAMP: `C:\wamp64\www\`
2. Start **Apache** and **MySQL** in XAMPP/WAMP Control Panel.
3. Open your browser and navigate to:
   - **Website Frontend:** `http://localhost/A35_Project/PawNest/index.php`
   - **Pets Listing:** `http://localhost/A35_Project/PawNest/pets.php`
   - **User Login:** `http://localhost/A35_Project/PawNest/login.php`
   - **Admin Panel:** `http://localhost/A35_Project/PawNest/admin/dashboard.php`
   - **Database Test:** `http://localhost/A35_Project/PawNest/php/testdb.php`

---

## 📋 Implemented CRUD Operations

### 1. CREATE (Insert data into database)
- **Add New Pet**:
  - Admin form: `admin/add-pet.html`
  - Backend: `php/add-pet.php` inserts a new pet record into the `pets` table.
- **Submit Adoption Application**:
  - Form: `adoption.php`
  - Backend: `php/submit-application.php` inserts user application details into the `applications` table.
- **User & Admin Registration**:
  - User: `register.php` -> `php/user-register.php` (inserts into `users` with `role = 'user'`).
  - Admin: `admin/admin-register.html` -> `php/admin-register.php` (inserts into `users` with `role = 'admin'`).

### 2. READ (Fetch and display data from database)
- **Featured Pets on Home Page**: `index.php` fetches available pets using `SELECT * FROM pets WHERE status = 'Available' LIMIT 3`.
- **Pet Catalog**: `pets.php` fetches all pets from MySQL database with category filtering (Dogs, Cats, Rabbits).
- **Pet Details**: `pet-details.php?id=<id>` retrieves a specific pet's information dynamically from MySQL.
- **User Application Tracking**: `my-applications.php` queries the `applications` table joined with `pets` to show application history and statuses.
- **Admin Dashboard**: `admin/dashboard.php` calculates live counts (`COUNT(*)`) for Total Pets, Available Pets, Applications, and Approved Applications.
- **Admin Manage Pets**: `admin/manage-pets.php` queries and lists all pets from the database.
- **Admin Applications**: `admin/applications.php` lists all adoption submissions.

### 3. UPDATE (Modify existing data in database)
- **Edit Pet Information**:
  - Page: `admin/edit-pet.php?id=<id>`
  - Updates pet name, type, breed, age, gender, description, image, and status in the `pets` table (`UPDATE pets SET ... WHERE id = :id`).
- **Approve / Reject Adoption Applications**:
  - Page: `admin/applications.php?action=approve&id=<id>`
  - Sets application status to `Approved` and automatically updates the pet's status to `Adopted`.
  - Also supports setting status to `Rejected`.

### 4. DELETE (Remove data from database)
- **Delete Pet**:
  - Script: `admin/delete-pet.php?id=<id>`
  - Removes the pet from the `pets` table (`DELETE FROM pets WHERE id = :id`).
- **Delete Application**:
  - Script: `admin/applications.php?action=delete&id=<id>`
  - Removes unwanted or archived applications from the `applications` table.

---

## 🛠️ Key Technical Improvements
- **PDO Database Wrapper (`php/db.php`)**:
  - Uses PDO prepared statements for protection against SQL injection.
  - Automatically handles local database connection whether MySQL password is empty (standard XAMPP) or `"root"` (MySQL Installer / Workbench).
- **Form Submission Fix (`js/validation.js`)**:
  - Fixed JavaScript validation functions that were previously returning `false`, allowing real form data to submit to the PHP backend scripts.
- **Clean Fallbacks**:
  - Pets display uploaded images from `images/` or fallback gracefully to animal emojis if image files are missing.
