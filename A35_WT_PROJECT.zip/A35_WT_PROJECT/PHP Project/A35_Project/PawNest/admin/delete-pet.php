<?php
session_start();
require_once __DIR__ . "/../php/db.php";

$id = (int)($_GET["id"] ?? 0);

if ($id > 0) {
    try {
        $stmt = $conn->prepare("DELETE FROM pets WHERE id = :id");
        $stmt->execute([":id" => $id]);
        header("Location: manage-pets.php?success=deleted");
        exit;
    } catch (PDOException $e) {
        die("Error deleting pet from database: " . $e->getMessage());
    }
} else {
    header("Location: manage-pets.php");
    exit;
}
