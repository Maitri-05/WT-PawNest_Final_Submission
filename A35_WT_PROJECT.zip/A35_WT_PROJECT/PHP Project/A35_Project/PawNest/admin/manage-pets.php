<?php
session_start();
require_once __DIR__ . "/../php/db.php";

try {
    $sql = "SELECT * FROM pets ORDER BY id ASC";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $pets = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching pets from database: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Manage Pets - PawNest</title>
</head>

<body>

    <!-- HEADER -->
    <header>
        <div class="logo">
            PawNest 🐾 <span style="font-size:14px; color:#666; font-weight:normal;">[Admin]</span>
        </div>

        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="manage-pets.php">Manage Pets</a>
            <a href="applications.php">Applications</a>
            <a href="../php/logout.php" style="color:#c0392b;">Logout</a>
        </nav>
    </header>


    <!-- PAGE HEADING -->
    <section class="page-heading">
        <h1>Manage Pets 🐾</h1>
        <p>
            Create, Read, Update, and Delete pets in the MySQL database.
        </p>
    </section>

    <!-- NOTIFICATIONS -->
    <?php if (isset($_GET["success"])) { ?>
        <div class="alert-box alert-success">
            <?php 
                if ($_GET["success"] === "added") echo "🐾 New pet added to database successfully!";
                elseif ($_GET["success"] === "updated") echo "✏️ Pet details updated successfully in database!";
                elseif ($_GET["success"] === "deleted") echo "🗑️ Pet removed from database successfully!";
            ?>
        </div>
    <?php } ?>


    <!-- MANAGE PETS -->
    <section class="manage-section">

        <div class="manage-top">
            <h2>Pet Database Records (<?php echo count($pets); ?>)</h2>
            <a href="add-pet.html" class="btn">
                + Add New Pet
            </a>
        </div>


        <!-- PET TABLE -->
        <div class="table-container">

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Pet</th>
                        <th>Type</th>
                        <th>Breed</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (!empty($pets)) { ?>
                        <?php foreach ($pets as $pet) { ?>
                            <tr>
                                <td><?php echo $pet["id"]; ?></td>

                                <td>
                                    <strong><?php echo htmlspecialchars($pet["name"]); ?></strong>
                                    <?php if (!empty($pet["image"])) { ?>
                                        <div style="font-size:12px; color:#888;"><?php echo htmlspecialchars($pet["image"]); ?></div>
                                    <?php } ?>
                                </td>

                                <td><?php echo htmlspecialchars($pet["type"]); ?></td>

                                <td><?php echo htmlspecialchars($pet["breed"]); ?></td>

                                <td><?php echo htmlspecialchars($pet["age"]); ?></td>

                                <td><?php echo htmlspecialchars($pet["gender"]); ?></td>

                                <td>
                                    <?php if ($pet["status"] === "Available") { ?>
                                        <span class="pet-status available-status">Available</span>
                                    <?php } elseif ($pet["status"] === "Adopted") { ?>
                                        <span class="pet-status adopted-status">Adopted</span>
                                    <?php } else { ?>
                                        <span class="pet-status pending-status"><?php echo htmlspecialchars($pet["status"]); ?></span>
                                    <?php } ?>
                                </td>

                                <td>
                                    <a href="edit-pet.php?id=<?php echo $pet["id"]; ?>" class="edit-btn">
                                        Edit
                                    </a>

                                    <a href="delete-pet.php?id=<?php echo $pet["id"]; ?>"
                                       class="delete-btn"
                                       onclick="return confirm('Are you sure you want to delete <?php echo addslashes(htmlspecialchars($pet['name'])); ?>?');">
                                        Delete
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="8" style="text-align:center; padding:30px; color:#777;">
                                No pets found in database. Click <strong>+ Add New Pet</strong> to insert one.
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>

        </div>

    </section>


    <!-- FOOTER -->
    <footer>
        <h3>PawNest 🐾</h3>
        <p>Where Every Pet Finds a Home.</p>
        <p class="copyright">© 2026 PawNest. All Rights Reserved.</p>
    </footer>

</body>
</html>
