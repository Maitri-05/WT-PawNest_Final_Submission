<?php
session_start();
require_once __DIR__ . "/../php/db.php";

$action = $_GET["action"] ?? "";
$id = (int)($_GET["id"] ?? 0);
$successMsg = "";

// Handle Actions
if ($id > 0 && in_array($action, ["approve", "reject", "delete"])) {
    try {
        if ($action === "approve") {
            // Set application to Approved
            $appStmt = $conn->prepare("UPDATE applications SET status = 'Approved' WHERE id = :id");
            $appStmt->execute([":id" => $id]);

            // Also update pet status to Adopted
            $petStmt = $conn->prepare("UPDATE pets SET status = 'Adopted' WHERE id = (SELECT pet_id FROM applications WHERE id = :id)");
            $petStmt->execute([":id" => $id]);

            $successMsg = "Application #$id has been Approved and the pet is marked as Adopted!";
        } elseif ($action === "reject") {
            $stmt = $conn->prepare("UPDATE applications SET status = 'Rejected' WHERE id = :id");
            $stmt->execute([":id" => $id]);
            $successMsg = "Application #$id has been marked as Rejected.";
        } elseif ($action === "delete") {
            $stmt = $conn->prepare("DELETE FROM applications WHERE id = :id");
            $stmt->execute([":id" => $id]);
            $successMsg = "Application #$id has been deleted from database.";
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}

// Fetch all applications
try {
    $sql = "SELECT a.*, p.name AS pet_name, p.type AS pet_type, p.breed AS pet_breed 
            FROM applications a 
            LEFT JOIN pets p ON a.pet_id = p.id 
            ORDER BY a.id DESC";
    $stmt = $conn->query($sql);
    $applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $applications = [];
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Applications - PawNest</title>
</head>

<body>

    <!-- HEADER -->
    <header>
        <div class="logo">
            PawNest 🐾 <span style="font-size:14px; color:#666; font-weight:normal;">[Admin]</span>
        </div>

        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="manage-pets.php">Manage Pets</a>
            <a href="applications.php">Applications</a>
            <a href="../php/logout.php" style="color:#c0392b;">Logout</a>
        </nav>
    </header>


    <!-- PAGE HEADING -->
    <section class="page-heading">
        <h1>Adoption Applications 📝</h1>
        <p>Review and manage adoption requests directly in the database.</p>
    </section>

    <!-- NOTIFICATION -->
    <?php if ($successMsg) { ?>
        <div class="alert-box alert-success"><?php echo htmlspecialchars($successMsg); ?></div>
    <?php } ?>
    <?php if (isset($error)) { ?>
        <div class="alert-box alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php } ?>

    <!-- APPLICATIONS SECTION -->
    <section class="manage-section">

        <div class="manage-top">
            <h2>All Applications (<?php echo count($applications); ?>)</h2>
        </div>


        <!-- APPLICATION TABLE -->
        <div class="table-container">

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Applicant</th>
                        <th>Pet</th>
                        <th>Date</th>
                        <th>Experience</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (!empty($applications)) { ?>
                        <?php foreach ($applications as $app) { ?>
                            <tr>
                                <td><?php echo $app["id"]; ?></td>

                                <td>
                                    <strong><?php echo htmlspecialchars($app["applicant_name"]); ?></strong><br>
                                    <small><?php echo htmlspecialchars($app["email"]); ?></small><br>
                                    <small><?php echo htmlspecialchars($app["phone"]); ?></small>
                                </td>

                                <td>
                                    <strong><?php echo htmlspecialchars($app["pet_name"] ?? "Pet #" . $app["pet_id"]); ?></strong>
                                    <br><small><?php echo htmlspecialchars($app["pet_breed"] ?? ''); ?></small>
                                </td>

                                <td><?php echo date("d M Y", strtotime($app["created_at"])); ?></td>

                                <td><?php echo htmlspecialchars($app["experience"]); ?></td>

                                <td style="max-width:200px; font-size:13px; color:#555;">
                                    <?php echo htmlspecialchars($app["reason"]); ?>
                                </td>

                                <td>
                                    <span class="application-status <?php echo strtolower($app['status']); ?>">
                                        <?php echo htmlspecialchars($app["status"]); ?>
                                    </span>
                                </td>

                                <td>
                                    <?php if ($app["status"] === "Pending") { ?>
                                        <a href="applications.php?action=approve&id=<?php echo $app['id']; ?>" class="approve-btn" onclick="return confirm('Approve this adoption application?');">Approve</a>
                                        <a href="applications.php?action=reject&id=<?php echo $app['id']; ?>" class="reject-btn" onclick="return confirm('Reject this application?');">Reject</a>
                                    <?php } ?>
                                    <a href="applications.php?action=delete&id=<?php echo $app['id']; ?>" class="delete-btn" onclick="return confirm('Permanently delete this application?');">Delete</a>
                                </td>
                            </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="8" style="text-align:center; padding:30px; color:#777;">
                                No adoption applications recorded yet.
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>

        </div>

    </section>


    <!-- FOOTER -->
    <footer>
        <h3>PawNest 🐾</h3>
        <p>Where Every Pet Finds a Home.</p>
        <p class="copyright">© 2026 PawNest. All Rights Reserved.</p>
    </footer>

</body>
</html>
