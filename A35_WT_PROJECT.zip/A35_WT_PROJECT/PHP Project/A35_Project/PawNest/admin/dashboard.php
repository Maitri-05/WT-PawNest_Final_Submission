<?php
session_start();
require_once __DIR__ . "/../php/db.php";

// Fetch dynamic statistics from database
try {
    $totalPets = (int)$conn->query("SELECT COUNT(*) FROM pets")->fetchColumn();
    $availablePets = (int)$conn->query("SELECT COUNT(*) FROM pets WHERE status = 'Available'")->fetchColumn();
    $totalApplications = (int)$conn->query("SELECT COUNT(*) FROM applications")->fetchColumn();
    $approvedApplications = (int)$conn->query("SELECT COUNT(*) FROM applications WHERE status = 'Approved'")->fetchColumn();

    // Recent pets
    $recentPets = $conn->query("SELECT * FROM pets ORDER BY id DESC LIMIT 4")->fetchAll(PDO::FETCH_ASSOC);

    // Recent applications
    $recentApps = $conn->query("SELECT a.*, p.name AS pet_name FROM applications a LEFT JOIN pets p ON a.pet_id = p.id ORDER BY a.id DESC LIMIT 4")->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $totalPets = $availablePets = $totalApplications = $approvedApplications = 0;
    $recentPets = [];
    $recentApps = [];
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../css/style.css">

    <title>Admin Dashboard - PawNest</title>
</head>

<body>

    <!-- HEADER -->
    <header>

        <div class="logo">
            PawNest 🐾 <span style="font-size:14px; color:#666; font-weight:normal;">[Admin Panel]</span>
        </div>

        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="manage-pets.php">Manage Pets</a>
            <a href="applications.php">Applications</a>
            <a href="../php/logout.php" style="color:#c0392b;">Logout</a>
        </nav>

    </header>


    <!-- PAGE HEADING -->
    <section class="page-heading">

        <h1>Admin Dashboard 🐾</h1>

        <p>
            Real-time database statistics and pet adoption management.
        </p>

    </section>


    <!-- DASHBOARD -->
    <section class="admin-dashboard">

        <div class="admin-welcome">

            <h2>Welcome<?php echo isset($_SESSION["admin_name"]) ? ", " . htmlspecialchars($_SESSION["admin_name"]) : ", Administrator"; ?>! 👋</h2>

            <p>
                Live metrics fetched directly from MySQL database <code>pawnest</code>.
            </p>

        </div>


        <!-- STATISTICS -->
        <div class="dashboard-stats">

            <div class="stat-card">
                <span>🐶</span>
                <h3>Total Pets</h3>
                <p><?php echo $totalPets; ?></p>
            </div>

            <div class="stat-card">
                <span>🏠</span>
                <h3>Available Pets</h3>
                <p><?php echo $availablePets; ?></p>
            </div>

            <div class="stat-card">
                <span>📝</span>
                <h3>Applications</h3>
                <p><?php echo $totalApplications; ?></p>
            </div>

            <div class="stat-card">
                <span>❤️</span>
                <h3>Approved</h3>
                <p><?php echo $approvedApplications; ?></p>
            </div>

        </div>


        <!-- ADMIN ACTIONS -->
        <h2 class="admin-title">Quick Actions</h2>

        <div class="admin-actions">

            <div class="admin-action-card">
                <span>🐾</span>
                <h3>Manage Pets</h3>
                <p>
                    Add new pets, update pet details, or remove pets from the database.
                </p>
                <a href="manage-pets.php" class="btn">
                    Manage Pets (CRUD)
                </a>
            </div>

            <div class="admin-action-card">
                <span>📋</span>
                <h3>Manage Applications</h3>
                <p>
                    Review adoption submissions, approve or reject applications in the database.
                </p>
                <a href="applications.php" class="btn">
                    View Applications
                </a>
            </div>

        </div>

    </section>


    <!-- FOOTER -->
    <footer>

        <h3>PawNest 🐾</h3>

        <p>Where Every Pet Finds a Home.</p>

        <p class="copyright">
            © 2026 PawNest. All Rights Reserved.
        </p>

    </footer>

</body>

</html>
