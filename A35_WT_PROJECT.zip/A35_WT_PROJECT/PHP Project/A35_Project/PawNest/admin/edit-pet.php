<?php
session_start();
require_once __DIR__ . "/../php/db.php";

$id = (int)($_GET["id"] ?? 0);

if ($id <= 0) {
    header("Location: manage-pets.php");
    exit;
}

$message = "";
$error = "";

// ================= UPDATE PET (POST) =================
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $type = trim($_POST["type"] ?? "");
    $breed = trim($_POST["breed"] ?? "");
    $age = trim($_POST["age"] ?? "");
    $gender = trim($_POST["gender"] ?? "");
    $description = trim($_POST["description"] ?? "");
    $image = trim($_POST["image"] ?? "");
    $status = trim($_POST["status"] ?? "Available");

    if ($name === "" || $type === "" || $breed === "" || $age === "" || $gender === "") {
        $error = "Please fill in all required fields.";
    } else {
        try {
            $sql = "UPDATE pets SET
                    name = :name,
                    type = :type,
                    breed = :breed,
                    age = :age,
                    gender = :gender,
                    description = :description,
                    image = :image,
                    status = :status
                    WHERE id = :id";

            $stmt = $conn->prepare($sql);
            $stmt->execute([
                ":name" => $name,
                ":type" => $type,
                ":breed" => $breed,
                ":age" => $age,
                ":gender" => $gender,
                ":description" => $description,
                ":image" => $image !== "" ? basename($image) : null,
                ":status" => $status,
                ":id" => $id
            ]);

            header("Location: manage-pets.php?success=updated");
            exit;

        } catch (PDOException $e) {
            $error = "Error updating pet: " . $e->getMessage();
        }
    }
}

// ================= FETCH PET (GET) =================
try {
    $sql = "SELECT * FROM pets WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([":id" => $id]);
    $pet = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$pet) {
        die("Pet not found in database. <a href='manage-pets.php'>Back to Manage Pets</a>");
    }
} catch (PDOException $e) {
    die("Error fetching pet: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Edit Pet - PawNest</title>
</head>

<body>

    <!-- HEADER -->
    <header>
        <div class="logo">PawNest 🐾</div>
        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="manage-pets.php">Manage Pets</a>
            <a href="applications.php">Applications</a>
            <a href="../php/logout.php" style="color:#c0392b;">Logout</a>
        </nav>
    </header>

    <!-- PAGE HEADING -->
    <section class="page-heading">
        <h1>Edit Pet: <?php echo htmlspecialchars($pet["name"]); ?> 🐾</h1>
        <p>Update pet information in the MySQL database.</p>
    </section>

    <!-- FORM SECTION -->
    <section class="admin-form-section" style="max-width:700px; margin:30px auto; background:#fff; padding:35px; border-radius:10px; box-shadow:0 3px 12px rgba(0,0,0,0.08);">

        <?php if (!empty($error)) { ?>
            <div class="alert-box alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php } ?>

        <form method="POST" action="edit-pet.php?id=<?php echo $pet['id']; ?>">

            <label for="name">Pet Name *</label>
            <input type="text" id="name" name="name"
                   value="<?php echo htmlspecialchars($pet["name"]); ?>" required>

            <label for="type">Pet Type *</label>
            <select id="type" name="type" required>
                <option value="Dog" <?php if ($pet["type"] === "Dog") echo "selected"; ?>>Dog</option>
                <option value="Cat" <?php if ($pet["type"] === "Cat") echo "selected"; ?>>Cat</option>
                <option value="Rabbit" <?php if ($pet["type"] === "Rabbit") echo "selected"; ?>>Rabbit</option>
                <option value="Bird" <?php if ($pet["type"] === "Bird") echo "selected"; ?>>Bird</option>
                <option value="Other" <?php if (!in_array($pet["type"], ["Dog","Cat","Rabbit","Bird"])) echo "selected"; ?>>Other</option>
            </select>

            <label for="breed">Breed *</label>
            <input type="text" id="breed" name="breed"
                   value="<?php echo htmlspecialchars($pet["breed"]); ?>" required>

            <label for="age">Age *</label>
            <input type="text" id="age" name="age"
                   value="<?php echo htmlspecialchars($pet["age"]); ?>" required>

            <label for="gender">Gender *</label>
            <select id="gender" name="gender" required>
                <option value="Male" <?php if ($pet["gender"] === "Male") echo "selected"; ?>>Male</option>
                <option value="Female" <?php if ($pet["gender"] === "Female") echo "selected"; ?>>Female</option>
            </select>

            <label for="description">Description</label>
            <textarea id="description" name="description" rows="4"><?php echo htmlspecialchars($pet["description"]); ?></textarea>

            <label for="image">Image Filename</label>
            <input type="text" id="image" name="image"
                   placeholder="e.g. bruno.webp or sweety.jpg"
                   value="<?php echo htmlspecialchars($pet["image"] ?? ''); ?>">

            <label for="status">Adoption Status *</label>
            <select id="status" name="status" required>
                <option value="Available" <?php if ($pet["status"] === "Available") echo "selected"; ?>>Available</option>
                <option value="Pending" <?php if ($pet["status"] === "Pending") echo "selected"; ?>>Pending</option>
                <option value="Adopted" <?php if ($pet["status"] === "Adopted") echo "selected"; ?>>Adopted</option>
            </select>

            <div style="margin-top:25px; display:flex; gap:12px;">
                <button type="submit" class="btn" style="flex:1;">Update Pet</button>
                <a href="manage-pets.php" class="btn" style="background:#888; text-align:center;">Cancel</a>
            </div>

        </form>

    </section>

    <!-- FOOTER -->
    <footer>
        <h3>PawNest 🐾</h3>
        <p>Where Every Pet Finds a Home.</p>
        <p class="copyright">© 2026 PawNest. All Rights Reserved.</p>
    </footer>

</body>
</html>
