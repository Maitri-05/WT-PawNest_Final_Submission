<?php
session_start();
if (isset($_SESSION["user_id"])) {
    header("Location: pets.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login - PawNest</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <!-- Navigation Bar -->
    <header>

        <div class="logo">
            🐾 PawNest
        </div>

        <nav>
            <a href="index.php">Home</a>
            <a href="pets.php">Pets</a>
            <a href="how-it-works.html">How It Works</a>
            <a href="about-us.html">About Us</a>
            <a href="login.php">Login</a>
        </nav>

    </header>


    <!-- Login Form -->
    <section class="form-section">

        <div class="form-container login-container">

            <h1>Welcome Back! 🐾</h1>

            <p class="form-intro">
                Login to continue your PawNest journey.
            </p>

            <?php if (isset($_GET["registered"])) { ?>
                <div class="alert-box alert-success">Registration successful! You may now log in.</div>
            <?php } ?>

            <form action="php/user-login.php" method="POST" onsubmit="return validateLogin()">

                <label for="email">Email Address</label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Enter your email"
                    required
                >


                <label for="password">Password</label>

                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter your password"
                    required
                >


                <button type="submit" class="btn">
                    Login
                </button>

            </form>


            <p class="form-link">
                Don't have an account?
                <a href="register.php">Create an account</a>
            </p>

            <p class="form-link" style="margin-top:10px;">
                Shelter Administrator?
                <a href="admin/admin-login.html">Admin Login here 🔐</a>
            </p>

        </div>

    </section>


    <!-- Footer -->
    <footer>

        <h3>🐾 PawNest</h3>

        <p>
            Where Every Pet Finds a Home.
        </p>

        <p class="copyright">
            © 2026 PawNest. All Rights Reserved.
        </p>

    </footer>
  <script src="js/validation.js"></script>
</body>
</html>
