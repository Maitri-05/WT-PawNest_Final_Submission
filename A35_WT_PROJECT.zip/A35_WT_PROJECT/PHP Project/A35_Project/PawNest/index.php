<?php
session_start();
require_once __DIR__ . "/php/db.php";

// Fetch featured pets from database
try {
    $stmt = $conn->query("SELECT * FROM pets WHERE status = 'Available' ORDER BY id ASC LIMIT 3");
    $featuredPets = $stmt->fetchAll();
} catch (PDOException $e) {
    $featuredPets = [];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PawNest - Pet Adoption</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <!-- Navigation Bar -->
    <header>
        <div class="logo">
            🐾 PawNest
        </div>

        <nav>
            <a href="index.php">Home</a>
            <a href="pets.php">Pets</a>
            <a href="how-it-works.html">How It Works</a>
            <a href="about-us.html">About Us</a>
            <?php if (isset($_SESSION["user_name"])) { ?>
                <a href="my-applications.php">My Applications</a>
                <span style="color:#e67e22; font-weight:bold; margin-left:15px;">Hi, <?php echo htmlspecialchars($_SESSION["user_name"]); ?>!</span>
                <a href="php/logout.php" style="color:#c0392b;">Logout</a>
            <?php } else { ?>
                <a href="login.php">Login</a>
                <a href="register.php" class="btn" style="padding:7px 15px; color:#fff;">Register</a>
            <?php } ?>
        </nav>
    </header>


    <!-- Hero Section -->
    <section class="hero">

        <div class="hero-text">
            <h1>Find Your New Best Friend 🐶</h1>
            <p>
                Every pet deserves a loving home.
                Find a furry friend and give them the
                forever home they deserve.
            </p>
            <a href="pets.php" class="btn">Find a Pet</a>
        </div>

        <div class="hero-image">
            🐕
        </div>

    </section>


    <!-- Featured Pets -->
    <section class="featured">

        <h2>Meet Our Lovely Pets 🐾</h2>

        <p class="section-text">
            These adorable pets are waiting for someone special to give them a loving home.
        </p>

        <div class="pet-container">

            <?php if (!empty($featuredPets)) { ?>
                <?php foreach ($featuredPets as $pet) { ?>
                    <div class="pet-card">
                        <div class="pet-image">
                            <?php 
                            $imgFile = !empty($pet["image"]) ? "images/" . $pet["image"] : "";
                            if ($imgFile && file_exists(__DIR__ . "/" . $imgFile)) {
                                echo '<img src="' . htmlspecialchars($imgFile) . '" alt="' . htmlspecialchars($pet["name"]) . '">';
                            } else {
                                echo ($pet["type"] === "Cat") ? "🐱" : (($pet["type"] === "Rabbit") ? "🐰" : "🐶");
                            }
                            ?>
                        </div>

                        <h3><?php echo htmlspecialchars($pet["name"]); ?></h3>
                        <p><?php echo htmlspecialchars($pet["breed"]); ?> • <?php echo htmlspecialchars($pet["age"]); ?></p>

                        <a href="pet-details.php?id=<?php echo $pet["id"]; ?>" class="card-btn">View Details</a>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <p style="text-align:center; color:#666;">No pets currently listed. Check back soon!</p>
            <?php } ?>

        </div>

    </section>


    <!-- How It Works -->
    <section class="how-it-works">

        <h2>How PawNest Works ❤️</h2>

        <div class="steps">

            <div class="step">
                <span>🔎</span>
                <h3>Find a Pet</h3>
                <p>Browse through pets looking for a loving home.</p>
            </div>

            <div class="step">
                <span>📝</span>
                <h3>Apply for Adoption</h3>
                <p>Submit a simple adoption application.</p>
            </div>

            <div class="step">
                <span>🏠</span>
                <h3>Give Them a Home</h3>
                <p>Welcome your new best friend into your family.</p>
            </div>

        </div>

    </section>


    <!-- Footer -->
    <footer>
        <h3>🐾 PawNest</h3>
        <p>Where Every Pet Finds a Home.</p>
        <p class="copyright">© 2026 PawNest. All Rights Reserved.</p>
    </footer>

</body>
</html>
